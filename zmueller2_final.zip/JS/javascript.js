var game = new Phaser.Game(1500, 600, Phaser.AUTO, '', { preload: preload, create: create, update: update });

  
function preload() {
  game.load.spritesheet( 'skier', 'images/skier.png', 128, 128);
  game.load.image('tree', 'images/tree.png');
	game.load.image('snow', 'images/snow.png');
	game.load.image('finish', 'images/finish.png');
  game.load.image('rock', 'images/rock.png');

		}

function create(){

	game.add.tileSprite(0, 0, 1500, 10000, 'snow');
  game.world.setBounds(0, 0, 1500, 10000);

  // Add the finish line
  var finish = game.add.sprite(100, game.world.height-250, 'finish');
  finish.scale.setTo(6, 1.5);


	//  use Arcade Physics 
  game.physics.startSystem( Phaser.Physics.ARCADE );

	 //  Add the skier to the middle of screen
	skier = game.add.sprite( 700, 50, 'skier');
        

  // Enable physics for skier 
  game.physics.arcade.enable( skier );
 

	// have camera stay on skier
	game.camera.follow( skier );

  // Add gravity
	skier.body.gravity.y = 300;
	skier.body.collideWorldBounds = true;

	// moving left and right actions
	skier.animations.add( 'left', [4], true );
	skier.animations.add( 'right', [3], true );

	// Create trees group and enable physics
	trees = game.add.group();
 trees.enableBody = true;

  // first tree spawn
	var x = 0, y = game.world.height - 700;

	// dont generate trees until y is greater than world height
	while(y > 500) {
       
  // generating tree on x and y coordinates
	var tree = trees.create( x, y, 'tree' );
	tree.body.immovable = true;

	// using the center to generate random trees
	var center = game.world.width;

	if( x > center ) {
		// if the last tree was to the right, put the next one on the left
    x = Math.random() * center;
		// if it was on the left, put the next one on the right
		x = center + Math.random() * (center - game.world.width);
		} else {
    // otherwise go left again
    x = Math.random() * center;
    }
		// place the next tree at least 200px higher and at most 300px higher
		y = y - 200 - 100 * Math.random();
	}
  //  Our controls.
  cursors = game.input.keyboard.createCursorKeys();


		}

function update() {

  //make skier restart when colliding with a tree
  //http://phaser.io/examples/v2/games/tanks helped me with respawn
  if (game.physics.arcade.collide( skier, trees)){
    skier.reset( 700, 50 );
  }




  // skier natural movement speed
  skier.body.velocity.x = 0;
	skier.body.velocity.y = 500;

	// Up goes slow, down goes fast
  if (cursors.up.isDown) {
    skier.body.velocity.y = 300;
    
  } else if ( cursors.down.isDown ) {
      skier.body.velocity.y = 800;

		}
      
	if (cursors.left.isDown) {

		//  Move to the left
		skier.body.velocity.x = -250;
		skier.animations.play('left');

	} else if (cursors.right.isDown) {

      //  Move to the right
		  skier.body.velocity.x = 250;
		  skier.animations.play('right');

		} else {

      //  Stand still
      skier.animations.stop();
      skier.frame = 2;

		    }

		}
